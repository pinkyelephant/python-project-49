from random import randint


def is_even(number):
    return number % 2 == 0


def question():
    number = randint(1, 100)
    print("Question: ", number)
    if is_even(number) is True:
        return "yes"
    return "no"


def answer():
    user_answer = input("Your answer:")
    return user_answer


def game_even():
    counter = 3
    for i in range(counter):
        ques = question()
        ans = answer()
        if ques == ans:
            print('Correct!')
            continue
        else:
            print(
                ans,
                "is wrong answer ;(. Correct answer was",
                ques,
                "."
                )
            return False
    return True
