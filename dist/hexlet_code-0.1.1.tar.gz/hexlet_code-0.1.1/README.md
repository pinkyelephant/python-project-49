### Hexlet tests and linter status:
[![Actions Status](https://github.com/pinkyelephant/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/pinkyelephant/python-project-49/actions)

### Codeclimate badge:
<a href="https://codeclimate.com/github/pinkyelephant/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/054b5c5811589a3d845a/maintainability" /></a>

### ASCINEMA link:

<a href="https://asciinema.org/a/IWeBqmrgxkVUx8uXt902L8WLh" target="_blank"><img src="https://asciinema.org/a/IWeBqmrgxkVUx8uXt902L8WLh.svg" /></a>

